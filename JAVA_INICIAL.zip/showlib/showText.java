package showlib;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.applet.*;

public class showText extends Applet {
	private TextField tf;
	private TextArea ta;
	private String nombre;

	public void init() {
		nombre=getParameter("FICHERO");
		setFont(new Font("Courier",Font.PLAIN,12));
		setLayout(new BorderLayout());
		add("North",tf=new TextField());
		tf.setBackground(Color.blue);
		tf.setForeground(Color.white);
		if (nombre!=null) { tf.setText(nombre); }
		add("Center",ta=new TextArea(8,40));
		ta.setEditable(false);
		ta.setBackground(Color.white);
		ta.setForeground(Color.black);
	}

	public void start() {
		try {
			URL url=new URL(getCodeBase(),nombre); 
			InputStream is=url.openStream();
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			byte[] B=new byte[1024];
			int N=0;
			do {
				ta.setText(Integer.toString(N));
				N=is.read(B);
				if (N>0) {
					baos.write(B,0,N);
				}
			} while (N>0);
			ta.setText(new String(baos.toByteArray()));
			is.close();
		} catch (MalformedURLException mue) {
			ta.setText("URL mal formado"); 
		} catch (IOException ioe) {
			ta.setText("ERROR de lectura");
		}
	}
}
package showlib;

import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.awt.event.*;
import java.applet.*;

public class showDir extends Applet implements Runnable, ItemListener {
	private java.awt.List lst;
	private TextField tf1,tf2;
	private miraTexto mt;
	private Thread thr;
	private URL base;
	private String nombre;
	private boolean agregarNombre;
	private Stack dirs;

	public void inicio() {
		nombre=getParameter("DIR");
		if (nombre==null) { 
			nombre="";
		}
		setFont(new Font("Courier",Font.PLAIN,12));
		setLayout(new BorderLayout());
		add("Center",lst=new java.awt.List());
		lst.setBackground(Color.white);
		lst.setForeground(Color.black);
		Panel p=new Panel();
		add("North",p);
		p.setLayout(new GridLayout(2,1));
		p.add(tf1=new TextField());
		tf1.setEditable(false);
		tf1.setBackground(Color.blue);
		tf1.setForeground(Color.white);
		p.add(tf2=new TextField(nombre));
		tf2.setEditable(false);
		tf2.setBackground(Color.blue);
		tf2.setForeground(Color.white);
		dirs=new Stack();

		lst.addItemListener(this);
	}

	public void init() {
		inicio();
		base=getCodeBase();
		tf1.setText(base.toExternalForm());
		tf1.setEditable(false);
	}

	public void start() {
		actualizar();
	}

	public void actualizar() {
		try {
			String s="";
			tf2.setText(nombre);
			base=new URL(tf1.getText());
			URL url=new URL(base,nombre); 
			InetAddress ina=InetAddress.getByName(url.getHost());
			String content=url.getContent().toString();
			s=s+"content="+content+"\n";
			if (content.indexOf(".text")>0)  { 
				new miraTexto(url,true); 
			} else {
				if (content.indexOf("URLInputStream")>0) {  // para Netscape
					agregarNombre=false; 
				} else {  // para IExplorer y appletviewer
					agregarNombre=true; 
				}
				if (esHTML(nombre)) {
					agregarNombre=false;
				}
				mt=new miraTexto(url,false);
				thr=new Thread(this);
				thr.start();
			}
		} catch (MalformedURLException mue) { }
		catch (IOException ioe) { }
	}

	private void actualizarLista() {
		StringTokenizer st=new StringTokenizer(mt.getText(),"<>");
		while (st.hasMoreTokens()) { 
			String link=getLink(st.nextToken());
			if (link!=null) {
				if (mt!=null) { // se han detectado v�nculos y se considerar� como un directorio
					mt.stop(); mt=null; 
					if (lst.getItemCount()>0) { 
//						lst.delItems(0,lst.countItems()-1); 
						for (int i=0;i<lst.getItemCount();i++) {
							lst.remove(i);
						}
					}
					if (agregarNombre) {
						if (nombre.lastIndexOf("/")<nombre.length()-1) { 
							nombre=nombre+"/";
						}
					}
					dirs.push(nombre); 
					if ((nombre.length()!=0)) {
						lst.add(".."); 
					}
				}
				if (agregarNombre) { 
					lst.add(nombre+link); 
				} else { 
					lst.add(link); 
				}
			}
		}
		if (mt!=null) { 
			mt.show(); 
		}
	}

	private String getLink(String s) {
		if (s.length()>6){
			String inicio=s.substring(0,6).toLowerCase();
			if (inicio.equals("a href")) {
				StringTokenizer auxst=new StringTokenizer(s,"=\"");
				auxst.nextToken();
				if (auxst.hasMoreTokens()) { 
					return auxst.nextToken(); 
				}
			}
		}
		return null;
	}

	private boolean esHTML(String s) {
		if (s==null) { 
			return false; 
		}
		String S=s.toLowerCase();
		if (S.length()<5) { 
			return false; 
		}
		if (S.lastIndexOf(".htm")==S.length()-4) { 
			return true; 
		}
		if (S.length()<5) { 
			return false; 
		}	
		if (S.lastIndexOf(".html")==S.length()-5) { 
			return true; 
		}
		return false;
	}

	public void run() {
		try {
			while (!mt.ready()) { 
				thr.sleep(50); 
			}
			actualizarLista();
		} catch (InterruptedException ie) {}
	}

	/*--------- Item Listener ---------------*/

	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange()==e.SELECTED) {
			nombre=(String) lst.getSelectedItem(); 
			if (nombre.startsWith("..")) { 
				dirs.pop();
				nombre=(String)dirs.pop(); 
			}
			actualizar();
		}
	}
/*
	public boolean action(Event ev,Object ob) {
		if (ev.target==lst) { 
			nombre=ob.toString(); 
			if (nombre.startsWith("..")) { 
				dirs.pop();
				nombre=(String)dirs.pop(); 
			}
		} else {
			nombre=tf2.getText();
		}
		actualizar();
		return true;
	}
*/
}
/*
 * @(#)calcWin.java	2.0 02/04/20
 *
 * Copyright 2002 Marta Oliver� & Jos� Luis Abreu.
 * Use is free. (Uso gratuito)
 */

/**
 * An applet with a button that opens a graphic calculator.
 * (Un applet con un bot�n que abre una calculadora gr�fica.)
 * calcWin.java, 1999.
 *
 * @author Jos� Luis Abreu
 * @author Marta Oliver�
 * @version 	2.0, 20 Apr 2002
 */

package ejem08;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class calcButton extends Applet implements ActionListener {

    /**
     * Construye un bot�n con etiqueta "calculadora" y lo pone en el applet.
     */
	public void init() { 
		setLayout(new GridLayout(1,1)); 
		Button b=new Button("calculadora");
		add(b);
		b.addActionListener(this);
	}

    /**
     * Responde a un click sobre el bot�n creando un objeto calcWin;
     */
	public void actionPerformed(ActionEvent e) {
		new calcWin();
	}
	
}
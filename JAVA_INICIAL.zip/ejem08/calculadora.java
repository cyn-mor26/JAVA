/*
 * @(#)calculadora.java	2.0 02/04/20
 *
 * Copyright 2002 Marta Oliver� & Jos� Luis Abreu.
 * Use is free. (Uso gratuito)
 */

/**
 * A command line calculator.
 * (Una calculadora que funciona desde la l�nea de comandos.)
 * calculadora.java, 1999.
 *
 * @author Jos� Luis Abreu
 * @author Marta Oliver�
 * @version 	2.0, 20 Apr 2002
 */
 
package ejem08;

import java.io.*;

public class calculadora {

    /**
     * Los operadores que reconocer� la calculadora.
     */
	private static final String[] operadores = {"+","-","*","/","=","-x","1/x"};
    /**
     * El valor acumulado. 
     * Se usa como primer operando al realizar una operaci�n binaria
     * o como el operando de una operaci�n unaria.
     */
	private double acumulado;
    /**
     * El segundo operando de una operaci�n binaria.
     */
	private double entrada;
    /**
     * El operador. Debe ser uno de los elementos de operadores.
     */
	private String operador;
	
    /**
     * El constructor �nico sin par�metros.
     */
	public calculadora() {
		limpiar();
	}

    /**
     * Pone en ceros la entrada y el acumulador y pone como operador "=".
     */
	public void limpiar() { 
		entrada=0.0; 
		acumulado=0.0; 
		operador="=";
	} 
	
    /**
     * Determina si la cadena s es un operador para esta calculadora.
     * Los operadores son "+", "-", "*", "/", "=", "-x" y "1/x"
     * @return true si s es uno de los operadores y false en caso contrario.
     */
	public static boolean esOperador(String s) {
		for (int i=0;i<operadores.length;i++) {
			if (operadores[i].equals(s)) {
				return true;
			}
		}
		return false;
	}

    /**
     * Determina si la cadena s es un operador binario para esta calculadora.
     * Los operadores binarios son "+", "-", "*" y "/".
     * @return true si s es uno de los operadores binarios y false en caso contrario.
     */
	public static boolean esOperadorBinario(String s) {
		return "+".equals(s)||"-".equals(s)||"*".equals(s)||"/".equals(s);
		
	}

    /**
     * Analiza la cadena s, la convierte en un double y asigna el valor a entrada.
     * Lanza una excepci�n si s no tiene formato de n�mero decimal.
     */
	public void entrarValor(String s) throws NumberFormatException {
		entrada=Double.valueOf(s).doubleValue();
	}
	
    /**
     * Define el operador activo como op si la cadena op es un operador 
     * de la calculadora y lanza una excepci�n en caso contrario.
     */
	public void definirOperador(String op) throws Exception {
		for (int i=0;i<operadores.length;i++) {
			if (operadores[i].equals(op)) {
				operador=op;
				return;
			}
		}
		throw new Exception("operador desconocido");
	}
	
    /**
     * Realiza la operaci�n usando los valores actuales de 
     * acumulador, operador y entrada y pone el resultado en acumulador.
     * Puede lanzar una excepci�n si la operaci�n es inv�lida,
     * por ejemplo si el operador="/" y entrada=0.0. 
     */
	public void realizarOperaci�n() throws Exception { 
		if (operador.equals("=")) {
			acumulado  = entrada;
		} else if (operador.equals("-x")) {
			acumulado  = -entrada;
		} else if (operador.equals("1/x")) {
			if (entrada !=0.0) {
				acumulado = 1/entrada;
			} else {
				throw new Exception("intento de dividir entre cero.");
			}
		} else if (operador.equals("+")) {
			acumulado += entrada;
		} else if (operador.equals("*")) {
			acumulado *= entrada;
		} else if (operador.equals("-")) {
			acumulado -= entrada;
		} else if (operador.equals("/")) {
			if (entrada !=0.0) {
				acumulado /= entrada;
			} else {
				throw new Exception("intento de dividir entre cero.");
			}
		}
	}
	
    /**
     * Devuelve el valor actual de entrada.
     */
	public String entrada() { 
		return Double.toString(redondear(entrada));
	}

    /**
     * Devuelve el valor actual de acumulador.
     */
	public String resultado() { 
		return Double.toString(redondear(acumulado)); 
	}
	
    /**
     * Devuelve el valor actual de operador.
     */
	public String operador() {
		return operador;
	}

    /**
     * Redondea x a 8 decimales.
     */
	private static double redondear(double x) {
		double pres=100000000.0;
		return (Math.round(x*pres)/pres);
	}


    /**
     * Crea un objeto calculadora, pide al usuario entrada de un n�mero 
     * y realiza la operaci�n por defecto que es "=", con lo cual
     * pasa al acumulador el valor de la entrada.
     * Mientras no ocurra una excepci�n:
     * pone el resultado como entrada,
     * pide al usuario un operador,
     * si el operador es binario pide otro n�mero,
     * realiza la operaci�n,
     * escribe el resultado en la consola.
     */
	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		calculadora C=new calculadora();
		try	{
			System.out.print("operando : "); 
			C.entrarValor(br.readLine());
			C.realizarOperaci�n();
			while (true) {
				C.entrarValor(C.resultado());
				System.out.print("operador : ");
				C.definirOperador(br.readLine());
				if (C.esOperadorBinario(C.operador())) {
					System.out.print("operando : "); 
					C.entrarValor(br.readLine());
				}
				C.realizarOperaci�n();
				System.out.println("resultado= "+C.resultado());
			} 
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
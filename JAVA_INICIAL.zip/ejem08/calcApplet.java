/*
 * @(#)calcApplet.java	2.0 02/04/20
 *
 * Copyright 2002 Marta Oliver� & Jos� Luis Abreu.
 * Use is free. (Uso gratuito)
 */

/**
 * An Applet-Calculator.
 * (Una calculadora en un Applet.)
 * calcApplet.java, 1999.
 *
 * @author Jos� Luis Abreu
 * @author Marta Oliver�
 * @version 	2.0, 20 Apr 2002
 */

package ejem08;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class calcApplet extends Applet implements ActionListener {

	private calculadora C;
	private Label pantalla;
	private char operador='=';
	private String n�mero="0";
	private boolean entradaNueva=true;
	
	private static final String[] etiqueta= {
		"CA" ,"CE" ,"*"  ,"/"  ,
		"7"  ,"8"  ,"9"  ,"+"  ,
		"4"  ,"5"  ,"6"  ,"-"  ,
		"1"  ,"2"  ,"3"  ,"1/x"  ,
		"."  ,"0"  ,"="  ,"-x"
	};

    /**
     * Construye el despliegue y los botones y crea una calculadora.
     */
	public void init() { 
		setBackground(Color.gray);
		setFont(new Font("Courier",Font.BOLD,14)); 
		setLayout(new BorderLayout()); 

		pantalla=new Label("0");
		pantalla.setAlignment(Label.RIGHT);
		pantalla.setFont(new Font("Courier",Font.BOLD,16)); 
		pantalla.setBackground(Color.black);
		pantalla.setForeground(Color.yellow);
		add("North",pantalla); 

		Panel teclado=new Panel(); 
		teclado.setLayout(new GridLayout(5,4));
		for (int i=0;i<etiqueta.length;i++) {
			Button b=new Button(etiqueta[i]);
			b.addActionListener(this);
			teclado.add(b);
		}
		add("Center",teclado);

		Label lb=new Label("Calculadora MJA");
		lb.setAlignment(Label.CENTER);
		lb.setFont(new Font("TimesRoman",Font.BOLD+Font.ITALIC,14)); 
		lb.setBackground(Color.blue);
		lb.setForeground(Color.cyan);
		add("South",lb);

		C=new calculadora();
	}

    /**
     * Interpreta los clicks en los botones y hace
     * llamadas a los m�todos de la calculadora.
     * 
     * Un click en "CA" llama a limpiar();
     * Un click en "CE" pone en cero el despiegue;
     * Un click en un d�gito o en "." agrega el caracter al despliegue.
     * Un click en un operador llama a entrarValor y realizarOperaci�n,
     * el resultado del la operaci�n se pone en el despliegue.
     */
	public void actionPerformed(ActionEvent e) {
		String n�mero=pantalla.getText();
		if (n�mero.equals("ERROR")) {
			n�mero="0";
		}
		String comando=e.getActionCommand();
		if (comando.equals("CA")) { 
			C.limpiar(); 
			n�mero="0";
			entradaNueva=true; 
		} else if (comando.equals("CE")) { 
			n�mero="0";
			entradaNueva=true;
		} else if (C.esOperador(comando)) {
			try {
				C.entrarValor(n�mero);
				C.realizarOperaci�n();
				C.entrarValor(C.resultado());
				C.definirOperador(comando);
				if (!C.esOperadorBinario(comando)) {
					C.realizarOperaci�n();
					C.definirOperador("=");
				}
				n�mero=C.resultado();
				entradaNueva=true;
			} catch (Exception ex) {
				C.limpiar();
				pantalla.setText("ERROR");
				return;
			}
		} else { 
			if (n�mero.equals("0") || entradaNueva) { 
				n�mero=""; 
				entradaNueva=false;
			}
			n�mero=n�mero+comando.toString(); 
			if (n�mero.startsWith(".")) { 
				n�mero="0"+n�mero; 
			}
		}
		pantalla.setText(n�mero);
	}

}


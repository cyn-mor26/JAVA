/*
 * @(#)calcWin.java	2.0 02/04/20
 *
 * Copyright 2002 Marta Oliver� & Jos� Luis Abreu.
 * Use is free. (Uso gratuito)
 */

/**
 * A graphic calculator in a window.
 * (Una calculadora en una ventana "windows".)
 * calcWin.java, 1999.
 *
 * @author Jos� Luis Abreu
 * @author Marta Oliver�
 * @version 	2.0, 20 Apr 2002
 */

package ejem08;

import java.awt.*;
import java.awt.event.*;

public class calcWin extends Frame implements WindowListener {

    /**
     * Crea un objeto calcWin.
     */
	public static void main(String[] args) {
		new calcWin();
	}

    /**
     * El constructor �nico crea la ventana,
     * le da dimensiones 200x300, la coloca en (80,60),
     * crea un objeto calcApplet y lo coloca en la ventana.
     * Finalmente muestra la ventana.
     */
	public calcWin() {
		super(" MJA ");
		addWindowListener(this);
		calcApplet a=new calcApplet();
		a.init();
		setLayout(new GridLayout(1,1));
		add(a);
		pack();
		setSize(200,300);
		setLocation(80,60);
		show();
	}

    /**
     * Libera la ventana y termina el programa.
     */
	public void windowClosing(WindowEvent e){
		dispose();
		System.exit(0);
	}
    public void windowOpened(WindowEvent e){}
    public void windowActivated(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
    
}
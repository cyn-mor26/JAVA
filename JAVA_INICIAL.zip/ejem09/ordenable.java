package ejem08;

public interface ordenable {
  public boolean menor_o_igual(Object o1,Object o2);
}
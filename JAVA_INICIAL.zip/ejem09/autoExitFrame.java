package ejem08;

import java.awt.*;
import java.awt.event.*;

public class autoExitFrame extends Frame implements WindowListener {

	protected boolean solo=false;
	
	public autoExitFrame(boolean solo) {
		this.solo=solo;
		addWindowListener(this);
	}

	public void windowClosing(WindowEvent e){
		setVisible(false);
		if (solo) {
			System.exit(0);
		}
	}

    public void windowOpened(WindowEvent e){}
    public void windowActivated(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
}

package ejem08;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class disco extends Frame implements ordenable, FilenameFilter,
	ActionListener, WindowListener {

	private String ext=".txt .java .htm .html .gif .jpg .jpeg";
	private java.awt.List lst;
	private TextField tf;
	private File dir;

	public static void main(String[] args) {
		new disco().start();
	}

	public disco() {
		setFont(new Font("Courier",Font.PLAIN,12));
		setLayout(new BorderLayout());
		add("Center",lst=new java.awt.List());
		add("South",tf=new TextField(ext));
		pack();
		setSize(200,400);
		setLocation(20,20);

		addWindowListener(this);
		tf.addActionListener(this);
		lst.addActionListener(this);
	}

	public void start()	{
		//    dir=new File(File.separator"\\");
		String sep=File.separator;
		dir=new File("c:"+sep+sep);
		refrescar();
		show();
	}

	public void stop() {
		setVisible(false);
		dispose();
	}

	private void refrescar() {
		for (int i=lst.getItemCount()-1;i>=0;i--) {
			lst.remove(i);
		}
		setTitle(dir.getAbsolutePath()); 
		lst.add("..");
		String[] nombre=dir.list(this);
		if (nombre.length>0) {
			insercionBinariaBis ib=new insercionBinariaBis(nombre,this);
			ib.ordena();
		}
		File[] file=new File[nombre.length];
		for (int i=0;i<nombre.length;i++) { 
			file[i]=new File(dir,nombre[i]);
		}
		for (int i=0;i<file.length;i++) { 
			if (file[i].isDirectory()) { 
				lst.add("<"+nombre[i]+">"); 
			}
		}
		for (int i=0;i<file.length;i++) { 
			if (file[i].isFile()) { 
				lst.add(nombre[i]); 
			}
		}
	}

	public boolean menor_o_igual(Object o1,Object o2) {
		String s1=o1.toString().toLowerCase(), 
		s2=o2.toString().toLowerCase();
		char[] cha1=s1.toCharArray();
		char[] cha2=s2.toCharArray();
		int K=Math.min(cha1.length,cha2.length);
		for (int k=0;k<K;k++) {
			if (cha1[k]>cha2[k]) { 
				return false; 
			} else if (cha1[k]<cha2[k]) { 
				return true; 
			}
		}
		return cha1.length<=cha2.length;
	}

/* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==tf) { 
			ext=tf.getText(); 
			refrescar(); 
		} else if (e.getSource()==lst) {
			String nom=e.getActionCommand();
			if (nom.charAt(0)=='<') { 
				nom=nom.substring(1,nom.length()-1); 
			}
			File test=new File(dir,nom);
			if (nom.equals("..")) { 
				String parent=dir.getParent();
				if (parent!=null) {
					test=new File(parent); 
					if (test==null) { 
						test=dir; 
					}
				}
			}
			if (test.isDirectory()) { 
				dir=test; 
				refrescar(); 
			} else if (esImagen(nom)) { 
				new miraImagen(test.getAbsolutePath()); 
			} else { 
				new miraTexto(test.getAbsolutePath(),true); 
			}
		}
	}

	public boolean esImagen(String nom)	{
		String s=nom.toLowerCase();
		if (esExtensi�n(".jpg",s))  { 
			return true; 
		} 
		if (esExtensi�n(".gif",s))  { 
			return true; 
		} 
		if (esExtensi�n(".jpeg",s)) { 
			return true; 
		} 
		return false; 
	}

	public boolean esExtensi�n(String ext,String str) {
		return (str.lastIndexOf(ext)==(str.length()-ext.length()));
	}

	public boolean accept(File d,String name) {
		if ((ext==null)||ext.equals(".*")) { 
			return true; 
		}
		String aux=name.toLowerCase();
		String auxext=ext.toLowerCase();
		File test=new File(d,name);
		if (test.isFile()) { 
			StringTokenizer st=new StringTokenizer(auxext," *");
			while (st.hasMoreTokens()) {
				if (esExtensi�n(st.nextToken(),aux)) { 
					return true; 
				}
			}
			return false;
		} else { 
			return true; 
		}
	}

	public void windowClosing(WindowEvent e){
		stop();
		System.exit(0);
	}

    public void windowOpened(WindowEvent e){}
    public void windowActivated(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
}
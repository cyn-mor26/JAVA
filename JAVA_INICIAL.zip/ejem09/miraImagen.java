package ejem08;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;

public class miraImagen extends autoExitFrame implements Runnable {
	private boolean ready=false;
	private imageCanvas ic;
	private Image ima;
	private Toolkit tk=Toolkit.getDefaultToolkit();

	public miraImagen(String nombre) {
		super(false);
		setTitle(nombre);
		ima=tk.getImage(nombre);
		start();
	}

	public miraImagen(URL url) {
		super(false);
		setTitle(url.getFile());
		ima=tk.getImage(url);
		start();
	}

	public void start()	{
		setLayout(new GridLayout(1,1));
		add(ic=new imageCanvas());
		new Thread(this).start();
	}

	public boolean ready() { 
		return ready; 
	}

	public Image getImage() { 
		return ima; 
	}

	public void run() {
		if (ima!=null) {
			MediaTracker tracker=new MediaTracker(this);
			tracker.addImage(ima,0);
			try { 
				tracker.waitForID(0); 
			} catch(InterruptedException e) {
				System.out.println(e.toString());
			}
		}
		ic.setImage(ima);
		pack();
		int sw=tk.getScreenSize().width;
		int sh=tk.getScreenSize().height;
		if (getSize().width>sw) { 
			setSize(sw,(sw*getSize().height)/getSize().width); 
		}
		if (getSize().height>sh) { 
			setSize((sh*getSize().width)/getSize().height,sh); 
		}
		int x=(sw-getSize().width)/2;
		int y=(sh-getSize().height)/2;
		if (x<0) { 
			x=0; 
		}
		if (y<0) { 
			y=0; 
		}
		setLocation(x,y);
		//    setResizable(false);
		show();
		ready=true;
	}

	public void stop() { 
		setVisible(false); 
		dispose();
	}

	public void windowClosing(WindowEvent e){
		stop();
		super.windowClosing(e);
	}
}

class imageCanvas extends Canvas {

	private Image ima;

	void setImage(Image ima) { 
		this.ima=ima; 
		setSize(ima.getWidth(this),ima.getHeight(this));
	}
	
	public void paint(Graphics g) {
		if (ima!=null) { 
			g.drawImage(ima,0,0,getSize().width,getSize().height,this); 
		}
	}

	public void update(Graphics g) { 
		paint(g); 
	}
}

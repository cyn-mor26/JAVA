package ejem08;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class miraTexto extends Frame implements Runnable, WindowListener {
	private boolean ready=false;
	private TextArea ta=new TextArea();
	private URL url;
	private boolean autoshow;

	public miraTexto(URL url,boolean autoshow) {
		this.url=url;
		this.autoshow=autoshow;
		addWindowListener(this);
		new Thread(this).start();
	}

	public miraTexto(String nombre,boolean autoshow) {
		setTitle(nombre);
		this.autoshow=autoshow;
		addWindowListener(this);
		try {
			RandomAccessFile raf=new RandomAccessFile(nombre,"r");
			byte[] b=new byte[(int)raf.length()];
			raf.readFully(b);
			raf.close();
			ta.setText(new String(b));
			start();
		} catch (IOException io) { }
	}

	public boolean ready() { return ready; }

	public String getText() { return ta.getText(); }

	public void start() {
		setLayout(new GridLayout(1,1));
		add(ta);
		ta.setFont(new Font("Courier",Font.PLAIN,12));
		ta.setEditable(false);
		ta.setBackground(Color.white);
		ta.setForeground(Color.black);
		pack();
		setSize(600,400);
		Toolkit tk=Toolkit.getDefaultToolkit();
		int sw=tk.getScreenSize().width;
		int sh=tk.getScreenSize().height;
		int x=(sw-getSize().width)/2;
		int y=(sh-getSize().height)/2;
		if (x<0) { 
			x=0;
		}
		if (y<0) {
			y=0;
		}
		setLocation(x,y);
		if (autoshow) { 
			show(); 
		}
	}

	public void stop() { 
		setVisible(false); 
		dispose();
	}

	public void run(){
		try {
			InputStream is=url.openStream();
			setTitle(url.getFile());
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			byte[] B=new byte[1024];
			int N=0;
			do {
				N=is.read(B);
				if (N>0) { 
					baos.write(B,0,N); 
				}
			} while (N>0);
			ta.setText(new String(baos.toByteArray()));
			start();
		} catch (IOException ioe) {}
		ready=true;
	}

	/*------------ WindowListener ----------*/
    public void windowOpened(WindowEvent e){}
    public void windowActivated(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		stop(); 
	}
}
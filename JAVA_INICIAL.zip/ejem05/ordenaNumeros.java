package ejem05;

public class ordenaNumeros extends insercionBinaria {

	protected boolean menor_o_igual(Object i1,Object i2){
		return ((Integer)i1).intValue()<=((Integer)i2).intValue();
	}

	public ordenaNumeros(Integer[] Ia) { 
		super(Ia); 
	}

	public static void main(String[] args) {
		Integer[] Ia=new Integer[20];
		for (int i=0;i<Ia.length;i++) {
			Ia[i]=new Integer((int)(Math.random()*1000));
			System.out.print(Ia[i].toString()+" ");
		}
		System.out.println();
		ordenaNumeros oc=new ordenaNumeros(Ia);
		oc.ordena();
		for (int i=0;i<Ia.length;i++) {
			System.out.print(Ia[i].toString()+" ");
		}
		System.out.println();
	}

}
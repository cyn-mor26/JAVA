package ejem05;

public class ordenaCadenasBis implements ordenable {
	public boolean menor_o_igual(Object s1,Object s2) {
		char[] cha1=((String)s1).toCharArray();
		char[] cha2=((String)s2).toCharArray();
		int K=Math.min(cha1.length,cha2.length);
		for (int k=0;k<K;k++) {
			if (cha1[k]>cha2[k]) { 
				return false; 
			} else if (cha1[k]<cha2[k]) { 
				return true; 
			}
		}
		return cha1.length<=cha2.length;
	}
	public static void main(String[] args) {
		ordenaCadenasBis oc=new ordenaCadenasBis();
		insercionBinariaBis ib=new insercionBinariaBis(args,oc);
		ib.ordena();
		for (int i=0;i<args.length;i++) {
			System.out.println(args[i]);
		}
	}
}
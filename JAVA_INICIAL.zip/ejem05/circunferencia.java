package ejem05;

import java.awt.*;

class circunferencia extends cosaDibujable {

	circunferencia(int x,int y,int r,Color c) {
		super(x,y,r,c);
	}

	void dibujar(Graphics g) {
		g.drawOval(x-r,y-r,2*r,2*r);
	}

}
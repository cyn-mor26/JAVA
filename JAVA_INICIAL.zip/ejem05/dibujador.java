package ejem05;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class dibujador extends Applet implements ActionListener {

	cosaDibujable cd;
	Button b1,b2,b3;

	public void init() {
		setBackground(Color.black);
		add(b1=new Button("tri�ngulo"));
		add(b2=new Button("cuadrado"));
		add(b3=new Button("circunferencia"));
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		int x=getSize().width/2;
		int y=getSize().height/2;
		int r=(getSize().width+getSize().height)/8;
		Color c=Color.yellow;
		if (e.getSource()==b1) { cd=new triangulo(x,y,r,c); }
		else if (e.getSource()==b2) { cd=new cuadrado(x,y,r,c); }
		else if (e.getSource()==b3) { cd=new circunferencia(x,y,r,c); }
		repaint();
	}

	public void paint(Graphics g) {
		if (cd!=null) { 
			cd.paint(g); 
		}
	}

}

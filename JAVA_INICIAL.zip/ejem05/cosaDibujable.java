package ejem05;

import java.awt.*;

abstract class cosaDibujable { 

	int x,y,r;
	Color c;

	abstract void dibujar(Graphics g);

	cosaDibujable(int x,int y,int r,Color c) {
		this.x=x; 
		this.y=y; 
		this.r=r; 
		this.c=c;
	}

	void paint(Graphics g) {
		g.setColor(c);
		dibujar(g);
	}
}
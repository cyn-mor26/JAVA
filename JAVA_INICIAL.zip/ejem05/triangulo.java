package ejem05;

import java.awt.*;

class triangulo extends cosaDibujable {

	triangulo(int x,int y,int r,Color c) {
		super(x,y,r,c);
	}

	void dibujar(Graphics g) {
		g.drawLine(x-r,y-r,x-r,y+r);
		g.drawLine(x-r,y+r,x+r,y+r);
		g.drawLine(x+r,y+r,x-r,y-r);
	}

}
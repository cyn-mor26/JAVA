package ejem05;

abstract public class insercionBinaria {

	private Object[] ob;

	public insercionBinaria(Object[] ob) { 
		this.ob=ob; 
	}

	abstract protected boolean menor_o_igual(Object o1,Object o2);

	private boolean moi(int i,int j) { 
		if (j>=ob.length) { 
			return true; 
		}
		return menor_o_igual(ob[i],ob[j]);
	}

	private void inserta(int i,int j) { 
		Object aux=ob[i];
		for (int k=i;k>j;k--) { 
			ob[k]=ob[k-1]; 
		} 
		ob[j]=aux; 
	}

	public void ordena() { 
	// m�todo de inserci�n binaria
		int klo=0, khi=0, k=0, j=1;
		while (true) { 
			if (j>=ob.length) {
				break;
			}
			if (!moi(j-1,j)) {  
				if (!moi(0,j)) { 
					inserta(j,0); 
				} else { 
					klo=0; 
					khi=j-1;
					while (true) { 
						if (klo>khi) {
							k=klo; 
							break; 
						}
						k=(klo+khi)/2;
						if (moi(k,j)) {
							klo=k+1;
						} else {
							khi=k-1;
						}
					}
					inserta(j,k); 
				}
			}
			j++;
		}
	}

}
package ejem05;

public class circulo extends punto {

	int R;

	void setR(int r) { R=r; }
	int getR() { return R; }
	void incRadius(int d) { R=R+d; }
	void decRadius(int d) { R=R-d; if (R<0) { R=0; } }

	public circulo(int x,int y,int r) {
		super(x,y);
		R=r;
	}

}

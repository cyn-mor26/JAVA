package ejem05;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class circApplet extends Applet implements ActionListener {
	circulo c;
	Panel pan=new Panel();
	Button[] b=new Button[6];
	Color color=new Color(240,120,60);

	public void left()   { c.moveLeft(10);  }
	public void right()  { c.moveRight(10);  }
	public void up()     { c.moveUp(10);  }
	public void down()   { c.moveDown(10);  }
	public void incR()   { c.incRadius(5);  }
	public void decR()   { c.decRadius(5);  }
	public void redraw() { repaint();  }

	public void setColor(int r,int g,int b) { 
		color=new Color(r,g,b);
	}

	public void init() {
		b[0]=new Button("X-");
		b[1]=new Button("X+");
		b[2]=new Button("Y+");
		b[3]=new Button("Y-");
		b[4]=new Button("R+");
		b[5]=new Button("R-");

		setBackground(Color.black);
		setLayout(new BorderLayout());
		add("South",pan);
		pan.setLayout(new GridLayout(1,6));
		for (int i=0; i<6;i++) { 
			pan.add(b[i]); 
			b[i].addActionListener(this);
		}
	}

	public void start() {
		c=new circulo(getSize().width/2,
			 (getSize().height-pan.getSize().height)/2,
			40);
	}

	public void actionPerformed(ActionEvent e) {
		for (int i=0;i<6;i++) {
			if (e.getSource()==b[i]) {
				switch (i) {
				case 0 : left();  break;
				case 1 : right(); break;
				case 2 : down();  break;
				case 3 : up();    break;
				case 4 : incR();  break;
				case 5 : decR();  break;
				}
				repaint();
				break;
			}
		}
	}

	public void paint(Graphics g) {
		g.setColor(color);
		g.fillOval(c.getX()-c.getR(),c.getY()-c.getR(),2*c.getR(),2*c.getR());
	} 

}
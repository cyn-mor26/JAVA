package ejem05;

import java.awt.*;

class cuadrado extends cosaDibujable {

	cuadrado(int x,int y,int r,Color c) {
		super(x,y,r,c);
	}

	void dibujar(Graphics g) {
		g.drawRect(x-r,y-r,2*r,2*r);
	}

}
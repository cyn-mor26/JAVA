package ejem05;

public class punto {

	int X,Y;

	void setX(int x) { X=x; }
	void setY(int y) { Y=y; }
	int getX() { return X; }
	int getY() { return Y; }
	void moveRight(int d) { X=X+d; }
	void moveLeft (int d) { X=X-d; }
	void moveDown (int d) { Y=Y+d; }
	void moveUp   (int d) { Y=Y-d; }

	public punto(int x,int y) {
		X=x; Y=y; 
	}

}

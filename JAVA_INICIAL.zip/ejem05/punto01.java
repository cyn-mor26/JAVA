package ejem05;

import java.io.*;

public class punto01 {

	public static void main(String[] args) {
		punto p=new punto(10,10);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.print("escribe la absicsa del punto p:");
		try {
			String s=br.readLine();
			p.X=Integer.parseInt(s);
		} catch (Exception e) {
			p.X=10;
		}
		System.out.print("escribe la ordenada del punto p:");
		try {
			String s=br.readLine();
			p.Y=Integer.parseInt(s);
		} catch (Exception e) {
			p.Y=10;
		}
		System.out.println("absicsa del punto p = "+p.getX());
		System.out.println("se aplica p.moveLeft(5) y...");
		p.moveLeft(5);
		System.out.println("absicsa del punto p = "+p.getX());
	}

}
package ejem05;

public class holaApplet extends helloApplet {

	public void start() {
		mensaje="Hola Mundo";
	}

}
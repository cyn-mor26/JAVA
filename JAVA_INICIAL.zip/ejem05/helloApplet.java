package ejem05;

import java.awt.*;
import java.applet.*;

public class helloApplet extends Applet { 

	String mensaje;

	public void init() {
		setBackground(Color.red);
		setForeground(Color.white);
		setFont(new Font("TimesRoman",Font.PLAIN,24));
	}

	public void start() {
		mensaje="Hello World";
	}

	public void paint(Graphics g) {
		FontMetrics fm=g.getFontMetrics();
		int x=(getSize().width-fm.stringWidth(mensaje))/2;
		int y=(getSize().height-fm.getHeight())/2;
		g.drawString(mensaje,x,y+fm.getAscent());
	}

}
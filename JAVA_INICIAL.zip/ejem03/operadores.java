package ejem03;

public class operadores {

	public static void main(String[] args) {
		int a,b,c;
		double x,y,z;
		String s;

		s="Hola"+" "+"World";
		System.out.println(s);
		a=3;
		b=5;
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		c=a+b;
		System.out.println("a + b = "+c);
		c=a*b;
		System.out.println("a * b = "+c);
		c=b/a;
		System.out.println("b / a = "+c);
		c=a/b;
		System.out.println("a / b = "+c);
		x=2.71828;
		y=3.1416;
		System.out.println("x = "+x);
		System.out.println("y = "+y);
		z=x+y;
		System.out.println("x + y = "+z);
		z=x*y;
		System.out.println("x * y = "+z);
		z=y/x;
		System.out.println("y / x = "+z);
		z=x/y;
		System.out.println("x / y = "+z);
	}

}
package ejem03;

public class matrices {

	public static void main(String[] args) {

		double[][] R=new double[3][3];
		R[0][0]=1.0;  R[0][1]= 0.0; R[0][2]= 0.0;
		R[1][0]=0.0;  R[1][1]= 0.5; R[1][2]= 0.8;
		R[2][0]=0.0;  R[2][1]=-0.8; R[2][2]= 0.5;
		System.out.println("Matriz R de 3x3:");
		for (int j=0;j<3;j++) {
			for (int i=0;i<3;i++) {
				System.out.print(R[j][i]+"  ");
			}
			System.out.println("");
		}
		double[][] S= { 
			{ 1.0, 0.0, 0.0 },
			{ 0.0, 0.5, 0.8 },
			{ 0.0,-0.8, 0.5 }
		  };
		System.out.println("Matriz S de 3x3:");
		for (int j=0;j<3;j++) {
			for (int i=0;i<3;i++) {
				System.out.print(S[j][i]+"  ");
			}
			System.out.println("");
		}

		double[] a={ 1.0, 0.0, 0.0 };
		double[] b={ 0.0, 0.5, 0.8 };
		double[] c={ 0.0,-0.8, 0.5 };
		double[][] T={a,b,c};
		System.out.println("Matriz T de 3x3:");
		for (int j=0;j<3;j++) {
			for (int i=0;i<3;i++) {
				System.out.print(T[j][i]+"  ");
			}
			System.out.println("");
		}

		double[][] M={ {0.1,0.2,0.3,0.4},{0.2,0.4,0.8,1.6}};
		System.out.println("Matriz M de 2x4:");
		for (int j=0;j<2;j++) {
			for (int i=0;i<4;i++) {
				System.out.print(M[j][i]+"  ");
			}
			System.out.println("");
		}

	} 

}
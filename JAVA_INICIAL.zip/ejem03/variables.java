package ejem03;

public class variables {

	public static void main(String[] args) {
		byte b1,b2;
		char ch1,ch2;
		short s1,s2;
		int i1;
		long l1,l2;
		String S;

		b1=75; s1=75; i1=75; l1=75L;
		System.out.println("b1="+b1);
		System.out.println("s1="+s1);
		System.out.println("i1="+i1);
		System.out.println("l1="+l1);
		b2=(byte)0xEF; 
		System.out.println("b2=(byte)0xEF="+b2);
		s2=(short)0xEF35; 
		System.out.println("s2=(short)0xEF35="+s2);
		l2=0x8899AAbbCCddEEffL;
		System.out.println("l2=0x8899AAbbCCddEEffL="+l2);
		ch1='\100'; ch2='\u0040';
		System.out.println("ch1=\'\\100\'="+ch1);
		System.out.println("ch2=\'\\u0040\'="+ch2);
		S="mi cadena";
		System.out.println(S);
		S="primera\040linea\nsegunda\u0020linea";
		System.out.println(S);
	}

}
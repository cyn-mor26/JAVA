/*
 * @(#)JavaBasico.java 1.0 02/02/21
 *
 * You can modify the template of this file in the
 * directory ..\JCreator\Templates\Template_1\Project_Name.java
 *
 * You can also create your own project template by making a new
 * folder in the directory ..\JCreator\Template\. Use the other
 * templates as examples.
 *
 */
package myprojects.javabasico;

import java.awt.*;
import java.awt.event.*;

class JavaBasico extends Frame {
	
	public JavaBasico() {
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
				System.exit(0);
			}
		});
	}

	public static void main(String args[]) {
		System.out.println("Starting JavaBasico...");
		JavaBasico mainFrame = new JavaBasico();
		mainFrame.setSize(400, 400);
		mainFrame.setTitle("JavaBasico");
		mainFrame.setVisible(true);
	}
}




/*****************************************************************************
Default browsercheck - Leave this one
******************************************************************************/
function lib_bwcheck(){ //Browsercheck (needed)
	this.ver=navigator.appVersion; this.agent=navigator.userAgent
	this.dom=document.getElementById?1:0
	this.ie5=(this.ver.indexOf("MSIE 5")>-1 && this.dom)?1:0;
	this.ie6=(this.ver.indexOf("MSIE 6")>-1 && this.dom)?1:0;
	this.ie4=(document.all && !this.dom)?1:0;
	this.ie=this.ie4||this.ie5||this.ie6
	this.mac=this.agent.indexOf("Mac")>-1
	this.opera5=this.agent.indexOf("Opera 5")>-1
	this.ns6=(this.dom && parseInt(this.ver) >= 5) ?1:0; 
	this.ns4=(document.layers && !this.dom)?1:0;
	this.bw=(this.ie6 || this.ie5 || this.ie4 || this.ns4 || this.ns6 || this.opera5 || this.dom)
	return this
}

var bw=new lib_bwcheck() //Making browsercheck object

var mDebugging=2 

oCMenu=new makeCoolMenu("oCMenu") 
oCMenu.useframes=0 
oCMenu.frame="frmMain"
oCMenu.useNS4links=1 
oCMenu.checkselect=0



oCMenu.pagecheck=1
oCMenu.checkscroll=2
oCMenu.resizecheck=1 
oCMenu.wait=1000 

oCMenu.usebar=1 
oCMenu.barcolor="transparent" 
oCMenu.barwidth="100%" 
oCMenu.barheight="menu" 
oCMenu.barx=0 
oCMenu.bary="menu"
oCMenu.barinheritborder=0 

oCMenu.rows=1
oCMenu.fromleft=10
oCMenu.fromtop=100 
oCMenu.pxbetween=0

avail="190+((toppage.x2-210)/6)" 
oCMenu.menuplacement=new Array(10,147,217,287,357,427,497,567,637)

oCMenu.level[0]=new Array() 
oCMenu.level[0].width=70 
oCMenu.level[0].height=22
oCMenu.level[0].bgcoloroff="#9D9DBF"
oCMenu.level[0].bgcoloron="#CCCCCC" 
oCMenu.level[0].textcolor="#FFFFFF"
oCMenu.level[0].hovercolor="#666699" 
oCMenu.level[0].style="font-family:arial,helvetica; font-size:12px; font-weight:bold;"
oCMenu.level[0].border=1 
oCMenu.level[0].bordercolor="#CCCCCC" 
oCMenu.level[0].offsetX=0 
oCMenu.level[0].offsetY=-1 
oCMenu.level[0].NS4font="arial,helvetica"
oCMenu.level[0].NS4fontSize="2"
oCMenu.level[0].NS4fontColor="white"
oCMenu.level[0].align="bottom" 

oCMenu.level[1]=new Array() 
oCMenu.level[1].width=110
oCMenu.level[1].height=22
oCMenu.level[1].bgcoloroff="#FFFFFF"
oCMenu.level[1].bgcoloron="#666699"
oCMenu.level[1].textcolor="#52527A"
oCMenu.level[1].hovercolor="#FFFFFF"
oCMenu.level[1].style="padding:2px; font-family:arial,helvetica; font-size:11px; font-weight:bold"
oCMenu.level[1].align="bottom" 
oCMenu.level[1].offsetX=0
oCMenu.level[1].offsetY=0
oCMenu.level[1].border=1 
oCMenu.level[1].bordercolor="#666699"
oCMenu.level[1].NS4font="arial,helvetica"
oCMenu.level[1].NS4fontSize="2"
oCMenu.level[1].NS4fontColor="black"

oCMenu.level[2]=new Array()
oCMenu.level[2].width=150
oCMenu.level[2].height=20
oCMenu.level[2].style="padding:2px; font-family: arial,helvetica; font-size:10px; font-weight:bold"
oCMenu.level[2].align="bottom" 
oCMenu.level[2].offsetX=0
oCMenu.level[2].offsetY=0
oCMenu.level[2].border=0 
oCMenu.level[2].bordercolor="transparent"
oCMenu.level[2].NS4fontSize="1"
oCMenu.level[2].NS4fontColor="black"
oCMenu.level[2].bgcoloroff="#FFFFFF"
oCMenu.level[2].bgcoloron="#FFFFFFF"
oCMenu.level[2].textcolor="black"
oCMenu.level[2].hovercolor="black"

oCMenu.makeMenu('top0','','UNI. 3: Variables, matrices y operadores','','',135,30)
oCMenu.makeMenu('top1','','Unidad 1','1.htm','',175,0)
	oCMenu.makeMenu('sub10','top1','�Qu� es Java? ','1.htm#queesjava','',175,0)
	oCMenu.makeMenu('sub11','top1','Applets','1.htm#applets','',175,0)
	oCMenu.makeMenu('sub12','top1','Aplicaciones','1.htm#aplicaciones','',175,0)
	oCMenu.makeMenu('sub13','top1','El "Software Development Kit"','1.htm#jdk','',175,0)
	oCMenu.makeMenu('sub14','top1','JCreator ','1.htm#JCreator','',175,0)
	oCMenu.makeMenu('sub15','top1','Java y JavaScript','1.htm#javascript','',175,0)
	oCMenu.makeMenu('sub16','top1','Paquetes del SDK','1.htm#paquetes','',175,0)
	oCMenu.makeMenu('sub17','top1','EJERCICIOS','Basico_Eje01.htm','',175,0)
		                 
oCMenu.makeMenu('top2','','&nbsp;Unidad 2','2.htm')
	oCMenu.makeMenu('sub20','top2','HelloWorld con el JDK ','2.htm','',180,0)
	oCMenu.makeMenu('sub21','top2','El applet HelloWeb con el JDK ','2.htm#primerapplet','',180,0)
	oCMenu.makeMenu('sub22','top2','EJERCICIOS','Basico_Eje02.htm','',180,0)		
	
oCMenu.makeMenu('top3','','&nbsp;Unidad 3','3.htm')
	oCMenu.makeMenu('sub31','top3','Variables (Tipos de datos b�sicos) ','3.htm#variables','',200,0)
	oCMenu.makeMenu('sub32','top3','Literales ','3.htm#literales ','',200,0)
	oCMenu.makeMenu('sub33','top3','Nombres de las variables ','3.htm#nombres ','',200,0)
	oCMenu.makeMenu('sub34','top3','Matrices ','3.htm#matrices','',200,0)
	oCMenu.makeMenu('sub35','top3','Variables est�ticas y constantes ','3.htm#static','',200,0)
	oCMenu.makeMenu('sub36','top3','Operadores ','3.htm#operadores','',200,0)
	oCMenu.makeMenu('sub37','top3','EJERCICIOS','Basico_Eje03.htm','',200,0)

oCMenu.makeMenu('top4','','&nbsp;Unidad 4','4.htm')
	oCMenu.makeMenu('sub40','top4','Condicionales y ciclos ','4.htm#flujo','',140,0)
	oCMenu.makeMenu('sub41','top4','Excepciones ','4.htm#excepciones','',140,0)
	oCMenu.makeMenu('sub42','top4','EJERCICIOS','Basico_Eje04.htm','',140,0)
	
oCMenu.makeMenu('top5','','&nbsp;Unidad 5','5.htm')
	oCMenu.makeMenu('sub50','top5','La programaci�n orientada a objetos','5.htm#peypoo','',250,0)
	oCMenu.makeMenu('sub51','top5','Clases y objetos ','5.htm#clasesyobjetos','',250,0)
	oCMenu.makeMenu('sub52','top5','Creaci�n de objetos ','5.htm#creacion','',250,0)
	oCMenu.makeMenu('sub53','top5','M�todos','5.htm#metodos','',250,0)
	oCMenu.makeMenu('sub54','top5','Herencia y extensi�n de clases (subclases)','5.htm#subclases','',250,0)
	oCMenu.makeMenu('sub55','top5','Modificadores','5.htm#modificadores','',250,0)
	oCMenu.makeMenu('sub56','top5','Sobrecarga y sobreescritura ','5.htm#overload','',250,0)
	oCMenu.makeMenu('sub57','top5','Clases abstractas','5.htm#abstract','',250,0)
	oCMenu.makeMenu('sub58','top5','Interfaces','5.htm#interfaces','',250,0)
	oCMenu.makeMenu('sub59','top5','An�lisis de un applet','5.htm#circApplet','',250,0)		
	oCMenu.makeMenu('sub591','top5','EJERCICIOS','Basico_Eje05.htm','',250,0)

oCMenu.makeMenu('top6','','&nbsp;Unidad 6','6.htm')
	oCMenu.makeMenu('sub060','top6','El paquete java.applet y la clase Applet','6.htm#applet','',240,0)
	oCMenu.makeMenu('sub061','top6','Inclusi�n de applets en p�ginas Web','6.htm#paginasweb','',240,0)
	oCMenu.makeMenu('sub062','top6','Im�genes','6.htm#imagenes','',240,0)
	oCMenu.makeMenu('sub063','top6','Sonido ','6.htm#sonido','',240,0)
	oCMenu.makeMenu('sub064','top6','Virtudes, defectos y rarezas de los applet ','6.htm#virtudes','',240,0)
	oCMenu.makeMenu('sub065','top6','EJERCICIOS','Basico_Eje06.htm','',240,0)

oCMenu.makeMenu('top7','','&nbsp;Unidad 7','7.htm')
	oCMenu.makeMenu('sub070','top7','Archivos y directorios (File) ','7.htm#Files','',280,0)
	oCMenu.makeMenu('sub071','top7','Corrientes de entrada y salida (Streams)','7.htm#Streams','',280,0)
	oCMenu.makeMenu('sub072','top7','Corrientes de texto','7.htm#Text','',280,0)
	oCMenu.makeMenu('sub073','top7','Corrientes de datos','7.htm#Data','',280,0)
	oCMenu.makeMenu('sub074','top7','Archivos de acceso aleatorio (RandomAccessFile)','7.htm#RAF','',280,0)
	oCMenu.makeMenu('sub075','top7','Otras corrientes de entrada y salida','7.htm#OtherStreams','',280,0)
	oCMenu.makeMenu('sub076','top7','Otras subclases de InputStream y OutputStream','7.htm#Subclasses','',280,0)
	oCMenu.makeMenu('sub077','top7','EJERCICIOS','Basico_Eje07.htm','',280,0)
				
oCMenu.makeMenu('top8','','&nbsp;Unidad 8','8.htm')
	oCMenu.makeMenu('sub080','top8','Aplicaciones','8.htm#aplicaciones','',215,0)
	oCMenu.makeMenu('sub081','top8','Aplicaciones aut�nomas y Applets','8.htm#aaya','',215,0)
	oCMenu.makeMenu('sub082','top8','Aplicaciones para l�nea de comandos','8.htm#aplc','',215,0)
	oCMenu.makeMenu('sub083','top8','Aplicaciones con interfaz gr�fica','8.htm#acig','',215,0)
	oCMenu.makeMenu('sub084','top8','Programaci�n gr�fica','8.htm#proggraf','',215,0)
    oCMenu.makeMenu('sub085','top8','EJERCICIOS','Basico_Eje08.htm','',215,0)
	
oCMenu.makeStyle(); oCMenu.construct()		

function cm_checkScrolled(obj){
	if(bw.ns4 || bw.ns6) obj.scrolledY=obj.win.pageYOffset
	else obj.scrolledY=obj.win.document.body.scrollTop
	if(obj.scrolledY!=obj.lastScrolled){
		if(!obj.useframes){
			self.status=obj.scrolledY
			if(obj.scrolledY>119){
				for(i=0;i<obj.l[0].num;i++){var sobj=obj.l[0].o[i].oBorder; sobj.moveY(obj.scrolledY)}
				if(obj.usebar) obj.oBar.moveY(obj.scrolledY)
			}else{
				for(i=0;i<obj.l[0].num;i++){var sobj=obj.l[0].o[i].oBorder; sobj.moveY(obj.fromtop)}
				if(obj.usebar) obj.oBar.moveY(obj.fromtop)
			}

		}
		obj.lastScrolled=obj.scrolledY; page.y=obj.scrolledY; page.y2=page.y2orig+obj.scrolledY
		if(!obj.useframes || bw.ie){ clearTimeout(obj.tim); obj.isover=0; obj.hideSubs(1,0)}
	}
	if((bw.ns4 || bw.ns6) && !obj.useframes) setTimeout("cm_checkScrolled("+obj.name+")",200)
}
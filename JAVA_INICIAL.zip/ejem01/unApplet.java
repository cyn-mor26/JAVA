package ejem01;

import java.applet.*;
import java.awt.*;

public class unApplet extends Applet implements Runnable {

	static final int R=75, r=8, d=2*r;
	double t;
	int x,y;
	Thread thr;
	boolean pleaseStop=false;

	public void init() {
		setBackground(Color.blue);
	}

	public void paint(Graphics g) {
		g.setColor(Color.blue);
		g.drawString("APPLET",x-15,y-2);
		g.drawOval(x,y,d,d);
		g.fillOval(x,y,d,d);
		x=100 - r + (int) (R*Math.cos(t));
		y=100 - r + (int) (R*Math.sin(t));
		g.setColor(Color.red);
		g.fillOval(x,y,d,d);
		g.setColor(Color.yellow);
		g.drawOval(x,y,d,d);
		g.drawString("APPLET",x-15,y-2);
	}
	
	public void start() {
		thr = new Thread(this);
		thr.start();
	}
	
	public void run() {
		try {
			t=0;
			while (!pleaseStop) {
				t+=0.031416;
				paint(getGraphics());
				thr.sleep(60);
			}
		} catch(InterruptedException e) {
		}
	}

	public void stop() {
		pleaseStop=true;
	}
	
}
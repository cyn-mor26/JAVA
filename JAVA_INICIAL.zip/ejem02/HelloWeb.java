package ejem02;

public class HelloWeb extends java.applet.Applet {

	public void paint(java.awt.Graphics g) {
		g.drawString("Hello Web!",70,50);
	}

}
package ejem02;

public class HelloWorld {

	public static void main(String[] args) {
		java.lang.System.out.println("Hello World!");
	}

}
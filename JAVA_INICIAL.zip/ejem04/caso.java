package ejem04;

public class caso {

	public static void main(String[] args) {
		switch (args.length) {
		case 0 : System.out.println("no hay par�metros");
		   break;
		case 1 : System.out.println("hay un par�metro");
		   break;
		case 2 : System.out.println("hay dos par�metros");
		   break;
		case 3 : System.out.println("hay tres par�metros");
		   break;
		default: System.out.println("hay m�s de tres par�metros");
		}
	}
}
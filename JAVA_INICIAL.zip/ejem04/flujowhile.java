package ejem04;

public class flujowhile {

	public static void main(String[] args) {
		int i=0;
		while (i<args.length) {
			System.out.println(args[i++]);
		}
	}

}
package ejem04;

import java.io.*;

public class finalmente {

	public static void main(String[] args) {
		try {
			int i=0;
			while (i<args.length) {
				if (args[i].equals("exit")) {
					return;
				}
				System.out.println(args[i]+" "); 
				i++; 
			}
		} finally  { 
			System.out.println("finalmente"); 
		}
		
	}

}
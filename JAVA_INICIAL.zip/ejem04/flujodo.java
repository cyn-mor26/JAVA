package ejem04;

public class flujodo {

	public static void main(String[] args) {
		if (args.length==0) {
			System.out.println("no hay par�metros");
		} else {
			int i=0;
			do { 
				System.out.println(args[i++]);
			} while (i<args.length);
		}
	}

}
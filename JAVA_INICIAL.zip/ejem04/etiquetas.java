package ejem04;

public class etiquetas {

	public static void main(String[] args) {
		int i=0;
	etiqueta1:
		while (i<args.length) 
	etiqueta2:
		{ 
			String s=args[i++];
			if (s.equals("break")) { break; }
			if (s.equals("continue"))  { continue; }
			if (s.equals("break1")) { break etiqueta1; }
			if (s.equals("break2")) { break etiqueta2; }
			if (s.equals("continue1")) { break etiqueta1; }
			if (s.equals("continue2")) { break etiqueta2; }
			System.out.println(s);
		} 
	}

}
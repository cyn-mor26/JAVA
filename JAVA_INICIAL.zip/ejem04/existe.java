package ejem04;

import java.io.*;

public class existe {

	public static void main(String[] args) {
		int i=0;
		while (i<args.length) {
			System.out.print(args[i]); 
			try {
				RandomAccessFile f=new RandomAccessFile(args[i],"r");
				f.close();
				System.out.print(" si"); 
			} catch (IOException e) { 
				System.out.print(" no"); 
			}
			System.out.println(" existe");
			i++; 
		}
	}

}
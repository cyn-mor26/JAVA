package ejem06;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;

public class sonidos extends imagenes implements ActionListener {

	AudioClip[] auc;

	public void init() {
		super.init();
		URL cb=getCodeBase();
		auc=new AudioClip[100];
		for (int i=0;i<100;i++) {
			String num=Integer.toString(i);
			if (num.length()<2) { 
				num="0"+num; 
			}
			auc[i]=getAudioClip(cb,getParameter("SONIDO"+num));
		}
	}

/* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		super.actionPerformed(e);
		if (auc[n]!=null) { 
			auc[n].play(); 
		}
	}
}
package ejem06;

import java.applet.*;
import java.awt.*;

public class applet1 extends Applet {

	public void init() {
		setBackground(Color.black);
	}

	public void cambia(int c) {
		switch (c%5) { 
		case 0: setBackground(Color.black); break;
		case 1: setBackground(Color.blue); break;
		case 2: setBackground(Color.green); break;
		case 3: setBackground(Color.yellow); break;
		case 4: setBackground(Color.red); break;
		}
		repaint();
	}
}
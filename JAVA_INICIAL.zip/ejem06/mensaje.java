package ejem06;

import java.applet.*;
import java.awt.*;

public class mensaje extends Applet {

	private Color cf,ct;
	private String letra;
	private int tama�o;
	private String mensaje;
	private Font font;

	public void init() {
		mensaje=getParameter("MENSAJE");
		letra=getParameter("LETRA");
		try	{
			tama�o=Integer.parseInt(getParameter("TAMA�O"));
		} catch(NumberFormatException nfe) { 
			tama�o=12; 
		}
		cf=leeColor(getParameter("FONDO"),Color.white);
		ct=leeColor(getParameter("COLOR"),Color.black);
		setBackground(cf);
		font=new Font(letra,Font.PLAIN,tama�o);
	}

	public void paint(Graphics g) {
		g.setColor(ct);
		g.setFont(font);
		FontMetrics fm=g.getFontMetrics();
		int x=(getSize().width-fm.stringWidth(mensaje))/2;
		int y=(getSize().height-fm.getHeight())/2;
		g.drawString(mensaje,x,y+fm.getAscent());
	}

	Color leeColor(String s,Color defcol) {
		if (s.equalsIgnoreCase("negro"))     { return Color.black; }
		if (s.equalsIgnoreCase("gris"))      { return Color.gray; }
		if (s.equalsIgnoreCase("grisObscuro")) { return Color.darkGray; }
		if (s.equalsIgnoreCase("grisClaro")) { return Color.lightGray; }
		if (s.equalsIgnoreCase("magenta"))   { return Color.magenta; }
		if (s.equalsIgnoreCase("azul"))      { return Color.blue; }
		if (s.equalsIgnoreCase("turquesa"))  { return Color.cyan; }
		if (s.equalsIgnoreCase("verde"))     { return Color.green; }
		if (s.equalsIgnoreCase("amarillo"))  { return Color.yellow; }
		if (s.equalsIgnoreCase("naranja"))   { return Color.orange; }
		if (s.equalsIgnoreCase("rojo"))      { return Color.red; }
		if (s.equalsIgnoreCase("rosa"))      { return Color.pink; }
		if (s.equalsIgnoreCase("blanco"))    { return Color.white; }
		try	{
			int c=Integer.parseInt(s,16); 
			return new Color(c);
		} catch (NumberFormatException nfe) { 
			return defcol; 
		}
	}
}
package ejem06;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class applet3 extends Applet implements ActionListener {

	Button b;
	TextArea ta;

	public void init() {
		setLayout(new BorderLayout());
		add("Center",ta=new TextArea(10,30));
		add("South",b=new Button("getApplets"));

		b.addActionListener(this);
	}

/* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		Enumeration en=getAppletContext().getApplets();
		String s="";
		while (en.hasMoreElements())	{ 
			s=s+((Applet)en.nextElement()).toString()+"\n"; 
		}
		ta.setText(s);
	}
}
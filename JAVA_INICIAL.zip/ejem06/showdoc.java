package ejem06;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class showdoc extends Applet implements ActionListener {

	Button b;
	Choice chLocation, chPage;

	public void init() {
		add(chLocation=new Choice());
		chLocation.addItem("_blank");
		chLocation.addItem("_self");
		chLocation.addItem("_parent");
		chLocation.addItem("_top");
		chLocation.addItem("miVentana");
		add(chPage=new Choice());
		chPage.addItem("Atardecer");
		chPage.addItem("Mandelbrot");
		chPage.addItem("Marilyn");
		chPage.addItem("Teo");
		add(b=new Button("showDocument"));
		b.addActionListener(this);

	}

  /* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==b) {
			try	{
				URL url=new URL(getDocumentBase(),
					"Show"+chPage.getSelectedItem()+".html");
				getAppletContext().showDocument(url,chLocation.getSelectedItem());
			} catch (MalformedURLException muo) {
			}
		}
	}
}
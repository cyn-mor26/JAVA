package ejem06;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;

public class imagenes extends Applet implements ActionListener {

	Button b;
	Image[] img;
	int n=0;
	MediaTracker mt;

	public void init() {
		setBackground(Color.magenta);
		add(b=new Button("siguiente"));
		URL cb=getCodeBase();
		img=new Image[100];
		mt=new MediaTracker(this);
		for (int i=0;i<100;i++)	{
			String num=Integer.toString(i);
			if (num.length()<2) { 
				num="0"+num; 
			}
			String auxs=getParameter("IMAGEN"+num);
			if (auxs!=null&&auxs.length()>0) {
				img[i]=getImage(cb,auxs);
				mt.addImage(img[i],i);
				try {
					mt.waitForID(i);
				} catch (InterruptedException ie) {
				}
			}
		}
		b.addActionListener(this);
	}

	public void start()	{
		n=0;
		while ((n<100)&&(img[n]==null)) { 
			n++; 
		}
	}

	public void paint(Graphics g) {
		if (mt.statusID(n,false)==MediaTracker.COMPLETE) {
			g.drawImage(img[n],0,0,getSize().width,getSize().height,this);
		} else { 
			g.drawString("la imagen "+n+" no est� disponible.",10,getSize().height/2); 
		}
	}

/* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==b)	{
			do { 
				n=(n+1)%100; 
			} while (img[n]==null);
			repaint();
		}
	}

}
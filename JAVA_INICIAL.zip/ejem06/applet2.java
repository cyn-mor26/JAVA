package ejem06;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class applet2 extends Applet implements ActionListener {

	Button b;
	public int c=0;

	public void init() {
		add(b=new Button("cambia color del otro applet"));
		b.addActionListener(this);
	}

/* --------------------- Action Listener ------------------ */

	public void actionPerformed(ActionEvent e) {
		AppletContext ac=getAppletContext();
		Applet ap=ac.getApplet("primero");
		applet1 ap1=(applet1)ap;
		if (ap1!=null) { 
			ap1.cambia(++c); 
		}
	}
}
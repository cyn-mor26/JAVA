package ejem07;

import java.io.*;

public class saveText {
	
	public static void main(String[] args) {
		try {
			System.out.println("");
			System.out.println("Escriba varias lineas de texto y termine con una vacia.");
			System.out.println("Cada linea se guardara en ejem07\\texto.txt.");
			System.out.println("");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			File f=new File("ejem07\\texto.txt");
			if (f.exists()) {
				f.delete();
			}
			BufferedWriter bw=new BufferedWriter(new FileWriter(f));
			while (true) {
				String line=br.readLine();
				if (line.length()==0) {
					break;
				}
				bw.write(line);
				bw.newLine();
			}
			bw.close();
			
			System.out.println("");
			System.out.println("Esto es lo que contiene ejem07\\texto.txt.");
			System.out.println("");
			br =new BufferedReader(new FileReader(f));
			while (true) {
				String line=br.readLine();
				if (line==null) {
					break;
				}
				System.out.println(line);
			}
		} catch (IOException e) {
			System.out.println(e);
		}
	}

}
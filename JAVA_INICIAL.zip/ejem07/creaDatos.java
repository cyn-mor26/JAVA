package ejem07;

import java.io.*;

public class creaDatos {
	
	public static void main(String[] args) {
		File f=new File("ejem07\\datos.dat");
		try {
			DataOutputStream dos=new DataOutputStream(new FileOutputStream(f));
			dos.writeBoolean(true);
			dos.writeByte(7);
			dos.writeUTF("Cadena en codigo UTF");
			dos.writeDouble(3.1416);
			dos.writeBytes("Cadena normal\nsegunda linea de la cadena");
			dos.close();
			System.out.println("El archivo creado tiene "+f.length()+" bytes.");
			System.out.println("Su contenido es:");
			DataInputStream dis=new DataInputStream(new FileInputStream(f));
			System.out.println("un boolean     :"+dis.readBoolean());
			System.out.println("un byte        :"+dis.readByte());
			System.out.println("una cadena UTF :"+dis.readUTF());
			System.out.println("un double      :"+dis.readDouble());
			BufferedReader br=new BufferedReader(new InputStreamReader(dis));
			System.out.println("una cadena     :"+br.readLine());
			System.out.println("               :"+br.readLine());
			dis.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

}
package ejem07;

import java.io.*;

public class dir implements FilenameFilter {
	String ext=".*";
	String directorio="."+File.separator;

	public static void main(String[] args) {
		dir D=new dir();
		if (args.length>0) { 
			D.directorio=args[0]; 
		}
		if (args.length>1) { 
			D.ext=args[1]; 
		}
		D.start();
	}

	public void start() {
		if (!ext.startsWith(".")) { 
			ext="."+ext; 
		}
		File d=new File(directorio);
		if (d.exists()) { 
			String[] files=d.list(this);
			for (int i=0;i<files.length;i++) {
				System.out.println(files[i]);
			}
		}
	}

	public boolean accept(File d,String name) {
		if ((ext==null)||ext.equals(".*")) { 
			return true; 
		}
		File test=new File(d,name);
		if (test.isFile()) { 
			return name.endsWith(ext); 
		} else { 
			return false; 
		}
	}

}


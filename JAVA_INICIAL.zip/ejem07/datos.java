package ejem07;

import java.io.*;
import java.util.*;
import java.text.*;

public class datos {

	public static void main(String[] args) {
		System.out.println("");
		File[] r=File.listRoots();
		System.out.print("RAICES DEL SISTEMA:");
		for (int i=0;i<r.length;i++) {
			System.out.print(" "+r[i].getPath());
		}
		System.out.println("");;
		if (args.length>0) { 
			for (int i=0;i<args.length;i++) {
				System.out.println("");
				File f=new File(args[i]);
				System.out.println("getPath()          ="+f.getPath());
				System.out.println("getName()          ="+f.getName());
				System.out.println("getParent()        ="+f.getParent());
				System.out.println("getAbsolutePath()  ="+f.getAbsolutePath());
				try {
					System.out.println("getCanonicalPath() ="+f.getCanonicalPath());
				} catch(IOException e) {
					System.out.println(e);
				}
				try {
					System.out.println("toURL()            ="+f.toURL());
				} catch(Exception e) {
					System.out.println(e);
				}
				if (f.exists()) {
					System.out.println("length()           ="+f.length()+" bytes");
					SimpleDateFormat sdf=new SimpleDateFormat();
					System.out.println("lastModified()     ="+sdf.format(new Date(f.lastModified())));
					System.out.print("Es un ");
					if (f.isDirectory()) {
						System.out.print("directorio");
					} else if (f.isFile()) {
						System.out.print("archivo");
					}
					if (f.canRead()) {
						System.out.print(" puede leerse");
					}
					if (f.canWrite()) {
						System.out.print(" puede modificarse");
					}
					if (f.isHidden()) {
						System.out.print(" es escondido");
					}
					System.out.println("");
				} else {
					System.out.println("No existe");
				}
				if (i+1<args.length) {
					System.out.println("");
					System.out.print("Pulse <intro> para continuar.");
					try {
						BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
						br.readLine();
					} catch (IOException e) {
					}
					System.out.println("");
				}
			}
		}
		System.out.println("");
	}

}


package ejem07;

import java.io.*;

public class leeFichero {
	
	public static void main(String[] args) {
		File f=new File("ejem07\\fichero.dat");
		try {
			InputStream in=new FileInputStream(f);
			for (int i=0;i<f.length();i++) {
				System.out.println(in.read());
			}
			in.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

}
package ejem07;

import java.io.*;

public class creaFichero {
	
	public static void main(String[] args) {
		File f=new File("ejem07\\fichero.dat");
		try {
			OutputStream o=new FileOutputStream(f);
			o.write(10);
			o.write(100);
			o.write(300);
			o.write(-10);
			o.flush();
			o.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

}
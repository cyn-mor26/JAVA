package ejem07;

import java.io.*;

public class copyFile {

	public static void main(String[] args) {
		System.out.println("");
		if (args.length==2) {
			File origen=new File(args[0]);
			try {
				if (!origen.exists()) {
					System.out.println("no se encuentra "+args[0]);
					return;
				}
				File destino=new File(args[1]);
				if (destino.exists()) {
					if (destino.equals(origen)) {
						System.out.println("no se puede copiar un archivo sobre si mismo.");
						return;
					}
					System.out.print(args[1]+" ya existe. sobrescribir? (s/n):");
					char r=(char)System.in.read();
					if (r=='s'||r=='S') { 
						destino.delete();
					} else {
						return;
					}
				}
				FileInputStream in=new FileInputStream(origen);
				FileOutputStream out=new FileOutputStream(destino);
				for (int i=0;i<origen.length();i++) {
					out.write(in.read());
				}
				out.flush();
				out.close();
				in.close();
				System.out.println(args[0]+" copiado a "+args[1]);
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}

}

